export default {
    demo: false,
    brand: 'Honeyside', // Footer brand
    appName: 'Clover', // App Name
    showCredits: true, // Show credits in login page
};
