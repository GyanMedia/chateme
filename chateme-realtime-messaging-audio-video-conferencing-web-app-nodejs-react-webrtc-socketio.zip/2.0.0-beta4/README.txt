READ THE DOCS

I'M SERIOUS. READ THE DOCS THOROUGHLY BEFORE REQUESTING SUPPORT.

You will find the docs in HTML format either in the docs folder (index.html) or online at https://docs.honeyside.it/clover/

Version: 2.0.0
Version warning: Read the Electron App section in the docs, packaging the Electron app is more difficult than running the web app and requires additional steps.
