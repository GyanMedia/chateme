#!/bin/bash

DOMAIN=$1
EMAIL=$2
USERNAME=$3
PASSWORD=$4
FIRST_NAME=$5
LAST_NAME=$6
SECRET=$7
PUBIP=$8

# Avoid Darwin
if [[ "$OSTYPE" != "linux-gnu" ]]; then
  echo "The automated installation script does not support your OS (are you on a Mac?). You can most probably install Clover manually."
  exit
fi

# Check parameters
if [ -z "$DOMAIN" ]
then
  echo "You need to specify a domain as first parameter."
  exit
fi
if [ -z "$EMAIL" ]
then
  echo "You need to specify an email as second parameter. This email will be used as a Let's Encrypt contact for SSL certificate generation and as email for the admin user."
  exit
fi
if [ -z "$USERNAME" ]
then
  echo "You need to specify a username as third parameter. It is required for the admin user."
  exit
fi
if [ -z "$PASSWORD" ]
then
  echo "You need to specify a password as fourth parameter. It is required for the admin user."
  exit
fi
if [ -z "$FIRST_NAME" ]
then
  echo "You need to specify a first name as fifth parameter. It is required for the admin user."
  exit
fi
if [ -z "$LAST_NAME" ]
then
  echo "You need to specify a last name as sixth parameter. It is required for the admin user."
  exit
fi
if [ -z "$SECRET" ]
then
  echo "You need to specify a token as seventh parameter. It is required for securing access on your website"
  exit
fi
if [ -z "$PUBIP" ]
then
  echo "You need to specify your machine public ip as eighth parameter. It is required for call functionality to work"
  exit
fi


# Welcome
echo ""
echo "Welcome to Clover!"
echo "This script will attempt fully automated installation on your machine."
echo "The domain you provided is $DOMAIN"
echo "The execution of this script may take several minutes."


# Build Essentials
echo ""
echo "Updating..."
sudo apt-get update
echo "Installing build essential packages..."
sudo apt-get install build-essential -y
sudo apt-get install python -y


# MongoDB
echo ""
echo "Installing MongoDB..."
sudo sudo apt-get install gnupg -y
sudo wget -qO - https://www.mongodb.org/static/pgp/server-4.2.asc | sudo apt-key add -
echo "deb [ arch=amd64 ] https://repo.mongodb.org/apt/ubuntu bionic/mongodb-org/4.2 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.2.list
sudo sudo apt-get update
sudo apt-get install -y mongodb-org
echo "Starting MongoDB..."
sudo systemctl daemon-reload
sudo systemctl start mongod
sudo systemctl enable mongod
echo "MongoDB started!"


# curl - nvm - Node.js - Yarn - pm2
echo ""
echo "Installing curl..."
sudo apt-get install curl -y
echo "Installing nvm..."
sudo curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.2/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion
. ~/.nvm/nvm.sh
. ~/.profile
. ~/.bashrc
echo "Installing Node.js 12.15.0..."
nvm install 12.15.0
echo "Installing Yarn..."
sudo curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
sudo apt update
sudo apt install --no-install-recommends yarn
echo "Installing pm2 globally..."
yarn global add pm2


# acacia
echo ""
echo "Installing Acacia (reverse proxy)..."
sudo apt install git -y
sudo git clone https://github.com/Honeyside/Acacia.git acacia
cd ./acacia || exit
yarn
cd ../
sudo rm -f acacia/config.js
echo "module.exports = {aliases: {\"www.$DOMAIN\": \"$DOMAIN\"}, certs: {default: {type: \"path\", cert: \"certs/127.0.0.1.cert\", key: \"certs/127.0.0.1.key\"}, \"$DOMAIN\": {type: \"letsencrypt\", email: \"$EMAIL\"}}, standard: [80], ssl: [443], servers: {\"80\": {\"$DOMAIN\": [{forceSSL: true}]}, \"443\": {\"$DOMAIN\": [{proxy: \"http://localhost:4000\", changeOrigin: true, secure: false, ws: true}]}}};" >> acacia/config.js
pm2 delete Acacia
cd ./acacia || exit
pm2 start index.js --name "Acacia"
cd ../


#Open ports
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -I INPUT -j ACCEPT
sudo /sbin/iptables-save


# Backend
echo ""
sudo rm -f node/config.js
echo "module.exports = {port: 4000, ip: '$PUBIP', secret: '$SECRET', admin: {username: '$USERNAME',email: '$EMAIL',password: '$PASSWORD',firstName: '$FIRST_NAME',lastName: '$LAST_NAME'}};" >> "./node/config.js"
echo "Installing backend node modules..."
cd ./node || exit
yarn
cd ../
echo "Starting backend..."
pm2 delete Clover
cd ./node || exit
pm2 start index.js --name "Clover"
cd ../
echo "Backend started!"


# Frontend
echo ""
sudo rm -f react/src/config.js
echo "export default {demo: false};" >> "./react/src/config.js"
echo "Installing frontend node modules..."
cd ./react || exit
yarn
echo "Building frontend..."
yarn build
echo "Frontend ready!"
cd ../


# Complete
echo ""
echo "Clover installation complete!"
