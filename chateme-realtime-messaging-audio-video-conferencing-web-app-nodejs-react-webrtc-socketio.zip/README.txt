Don't use Clover v2.0.0-alpha7 in production. It is a development version and it does not have all of the features that v1 has.

Missing features in v2.0.0-beta3 that will be required before replacing v1.4.0:
- Meetings tab
- Theming

Change log from beta2:
- Sounds added (ringing and message in)
- Highlight rooms with unread messages

Change log from beta1:
- Status dots
- User status
- Bug fixing