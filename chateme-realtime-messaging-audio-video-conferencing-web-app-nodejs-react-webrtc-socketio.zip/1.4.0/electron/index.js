const { app, BrowserWindow } = require('electron');

const createWindow = () => {
    // create browser window
    let win = new BrowserWindow({
        title: "Clover",
        width: 1280,
        height: 720,
        webPreferences: {
            nodeIntegration: true
        },
        show: false,
        icon: './electron-icon.ico',
    });

    // load file
    win.loadFile('app/index.html');

    win.maximize();
    win.show();
};

app.whenReady().then(createWindow);
