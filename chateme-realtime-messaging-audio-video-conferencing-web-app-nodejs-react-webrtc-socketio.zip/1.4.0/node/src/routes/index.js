const router = require('express').Router();
const passport = require('passport');
const jwt = require('express-jwt');
const Config = {...require('../defaults'), ...require('../../config')};

router.get('/images/:id', require('./images'));
router.get('/images/:id/:size', require('./images'));
router.post('/login', require('./login'));
router.post('/upload', passport.authenticate('jwt', {session: false}, null), require('./upload'));
router.post('/register', require('./register'));
router.post('/user/delete', jwt({secret: Config.secret}), require('./user-delete'));
router.post('/user/edit', jwt({secret: Config.secret}), require('./user-edit'));
router.post('/user/list', jwt({secret: Config.secret}), require('./user-list'));

module.exports = router;
