module.exports = {
    port: 80,
    retryAfter: 10000,
    secret: 'jwt-default-secret',
    db: 'mongodb://localhost:27017/clover',
    dataFolder: './data',
    admin: {
        username: 'admin',
        email: 'admin@example.com',
        password: 'admin',
        firstName: 'Admin',
        lastName: 'User',
    },
    sizes: [256, 512, 1024, 2048],
    sip: {
        enabled: false,
        type: 'onsip',
        adminAddress: {
            address: 'admin@example.onsip.com',
            user: 'example',
            password: 'admin',
        },
    },
};
