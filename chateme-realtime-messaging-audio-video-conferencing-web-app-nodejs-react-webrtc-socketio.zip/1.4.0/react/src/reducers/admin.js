import User from "../variables/actions/User";
import Actions from "../variables/actions/Actions";

const initialState = {
    error: null,
    status: null,
    username: null,
    view: null,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.ADMIN_USER_CREATE_RESULT:
            return {
                ...state, error: null, status: 'CREATED', username: action.username, view: null,
            };
        case Actions.ADMIN_USER_UPDATE_RESULT:
            return {
                ...state, error: null, status: 'UPDATED', username: action.username, view: null,
            };
        case Actions.ADMIN_USER_DELETE_RESULT:
            return {
                ...state, error: null, status: 'DELETED', username: action.username, view: null,
            };
        case Actions.ADMIN_USER_CREATE_ERROR:
        case Actions.ADMIN_USER_UPDATE_ERROR:
        case Actions.ADMIN_USER_DELETE_ERROR:
            return {
                ...state,
                error: action.error && action.error.response && action.error.response.data,
                username: action.username,
            };
        case Actions.ADMIN_VIEW_CREATE:
            return {
                ...state, view: 'CREATE',
            };
        case Actions.ADMIN_VIEW_UPDATE:
            return {
                ...state, view: 'EDIT',
            };
        case Actions.ADMIN_VIEW_DELETE:
            return {
                ...state, view: 'DELETE',
            };
        case Actions.ADMIN_VIEW_CANCEL:
            return {
                ...state, view: null,
            };
        case Actions.ADMIN_USER_CREATE:
        case Actions.ADMIN_USER_UPDATE:
        case Actions.ADMIN_USER_DELETE:
            return {
                ...state, status: null, error: null,
            };
        default:
            return state;
    }
};

export default reducer;
