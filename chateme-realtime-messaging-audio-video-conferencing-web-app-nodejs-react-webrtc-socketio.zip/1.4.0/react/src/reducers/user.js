import User from "../variables/actions/User";
import Actions from "../variables/actions/Actions";

const initialState = {
    favorites: [],
    login: {},
    register: {},
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.TOGGLE_FAVORITE_RESULT:
        case Actions.LIST_FAVORITES_RESULT:
            return {
                ...state, favorites: action.data.favorites
            };
        case User.USER_LOGIN:
            return {
                ...state, login: {},
            };
        case User.USER_REGISTER:
            return {
                ...state, register: {},
            };
        case User.USER_LOGIN_SUCCESS:
            return {
                ...state, ...action.user, token: action.token, login: {}, register: {},
            };
        case User.USER_LOGOUT:
            return initialState;
        case Actions.CHANGE_PICTURE_RESULT:
            return {
                ...state, picture: action.data.picture
            };
        case User.USER_LOGIN_FAILURE:
            if (action.error.response) return {
                ...state, login: action.error.response.data
            };
            return state;
        case User.USER_REGISTER_FAILURE:
            if (action.error.response) return {
                ...state, register: action.error.response.data
            };
            return state;
        default:
            return state;
    }
};

export default reducer;
