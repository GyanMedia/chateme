import Actions from "../variables/actions/Actions";
import Status from "../variables/Status";
import User from "../variables/actions/User";

const initialState = {
    ref: 0,
    progress: -1,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.UPLOAD_SUCCESS:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.SUCCESS, image: action.result.data.image, progress: 100}
            };
        case Actions.UPLOAD_PROGRESS:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.PROGRESS, progress: action.data}
            };
        case Actions.UPLOAD_ERROR:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.ERROR, err: action.err, progress: -1}
            };
        case Actions.UPLOAD_IMAGE:
            return {
                ...state, ref: state.ref + 1
            };
        case User.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};

export default reducer;
