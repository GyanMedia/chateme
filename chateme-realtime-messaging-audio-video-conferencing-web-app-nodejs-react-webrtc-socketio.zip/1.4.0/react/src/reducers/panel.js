import User from "../variables/actions/User";
import Actions from "../variables/actions/Actions";

const initialState = {
    rooms: [],
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.LIST_ROOMS_RESULT:
            return {
                ...state, rooms: action.data.rooms
            };
        case Actions.MORE_ROOMS_RESULT:
            return {
                ...state,
                rooms: [...state.rooms, ...action.data.rooms],
            };
        case User.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};

export default reducer;
