import User from "../variables/actions/User";
import Actions from "../variables/actions/Actions";
import xss from "xss";

const initialState = {
    images: [],
    messages: [],
    firstMessageID: null,
    lastMessageID: null,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.CREATE_ROOM_RESULT:
        case Actions.JOIN_ROOM_RESULT:
            return {
                ...state,
                ...action.data.room,
                picture: action.data.room.picture || null,
                firstMessageID: action.data.room.messages.length > 0 ? action.data.room.messages[0]._id : state.firstMessageID,
                lastMessageID: action.data.room.messages.length > 0 ? action.data.room.messages[action.data.room.messages.length - 1]._id : state.lastMessageID,
            };
        case Actions.ADD_MESSAGE:
            let message = action.message;
            message.content = xss(message.content);
            return {
                ...state,
                messages: [...state.messages, message],
                images: action.message.type === 'image' ? [action.message, ...state.images] : state.images,
                lastMessageID: action.message._id,
            };
        case Actions.MORE_MESSAGES_RESULT:
            return {
                ...state,
                messages: [...action.data.messages, ...state.messages],
                firstMessageID: action.data.messages.length > 0 ? action.data.messages[0]._id : state.firstMessageID,
            };
        case Actions.MORE_IMAGES_RESULT:
            return {
                ...state,
                images: [...state.images, ...action.data.images],
            };
        case User.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};

export default reducer;
