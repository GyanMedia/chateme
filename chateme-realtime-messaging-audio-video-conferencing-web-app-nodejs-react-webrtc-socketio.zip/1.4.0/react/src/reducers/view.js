import Views from "../variables/Views";
import View from "../variables/actions/View";
import Actions from "../variables/actions/Actions";
import User from "../variables/actions/User";

const initialState = {
    nav: Views.CHAT,
    navBackup: Views.CHAT,
    main: Views.WELCOME,
    mainBackup: Views.WELCOME,
    panel: Views.CHAT,
    panelBackup: Views.CHAT,
    details: Views.DETAILS,
    mobile: Views.WELCOME,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.SHOW_HOME:
            return {
                ...state, main: Views.WELCOME, mobile: Views.WELCOME,
            };
        case Actions.CREATE_ROOM_RESULT:
        case Actions.JOIN_ROOM_RESULT:
            return {
                ...state, main: Views.ROOM, mainBackup: Views.ROOM, mobile: Views.ROOM
            };
        case Actions.RTC_SESSION_ACCEPTED:
            return {
                ...state, main: Views.SESSION, mobile: Views.SESSION, nav: Views.SESSION,
            };
        case View.NAVIGATE:
            const { nav } = action;
            if ([Views.SESSION, Views.INCOMING, Views.OUTGOING, Views.DETAILS].includes(nav))
                return {
                    ...state, nav, mobile: nav, main: nav,
                };
            return {
                ...state, nav, panel: nav, mobile: Views.PANEL,
            };
        case Actions.SEARCH:
            if ([Views.CREATE_GROUP, Views.EDIT_GROUP, Views.RTC_GROUP_CREATE, Views.RTC_GROUP_ADD, Views.ADMIN].includes(state.panel)) return state;
            return {
                ...state,
                panel: Views.SEARCH,
                panelBackup: state.panel === Views.SEARCH ? state.panelBackup : state.panel,
                nav: Views.SEARCH,
                navBackup: state.panel === Views.SEARCH ? state.navBackup : state.nav,
            };
        case Actions.RTC_OUTGOING:
            return {
                ...state, main: Views.OUTGOING, mobile: Views.OUTGOING, nav: Views.OUTGOING,
            };
        case Actions.RTC_INCOMING:
            return {
                ...state, main: Views.INCOMING, mobile: Views.INCOMING, nav: Views.INCOMING,
            };
        case Actions.RTC_TERMINATED:
            return {
                ...state, main: state.mainBackup, mobile: state.mainBackup,
            };
        case User.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};

export default reducer;
