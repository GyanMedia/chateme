import React, {useEffect, useState} from 'react';
import './App.sass';
import {useDispatch, useSelector} from "react-redux";
import Loader from 'react-loader-spinner';
import Login from "./features/Login/Login";
import Desktop from "./features/Home/Desktop";
import Tablet from "./features/Home/Tablet";
import Phone from "./features/Home/Phone";
import jwtDecode from "jwt-decode";
import User from "./variables/actions/User";
import Actions from "./variables/actions/Actions";

function App() {
  const dispatch = useDispatch();
  const id = useSelector(state => state.user.id);
  const exp = useSelector(state => state.user.exp);
  const [width, setWidth] = useState(window.innerWidth);
  const [height, setHeight] = useState(window.innerHeight);

  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token || typeof token !== 'string') return;

    const user = jwtDecode(token);

    // dispatch a success action to the store
    dispatch({ type: User.USER_LOGIN_SUCCESS, user, token, keep: true });
    dispatch({ type: Actions.RTC_REGISTER });

    // shameful tricks for mobile
    window.onresize = () => {
      console.log(width);
      let vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
      if (Math.abs(window.innerWidth - width) > 50) setWidth(window.innerWidth);
      if (Math.abs(window.innerHeight - height) > 50) setHeight(window.innerWidth);
    };

    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);

    let focusCount = 0;
    setInterval(() => {
      if (window.busy) return;
      if (!document.hasFocus()) {
        focusCount++;
        if (focusCount === 10) {
          dispatch({ type: Actions.STATUS_LOST_FOCUS });
          window.socket.emit('away');
        }
      }
      else if (focusCount !== 0) {
        focusCount = 0;
        dispatch({ type: Actions.STATUS_FOCUS });
        window.socket.emit('online');
      }
    }, 1000);
  },[]);

  useEffect(() => {
    // shameful tricks for mobile
    window.onresize = () => {
      console.log(width);
      let vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
      if (Math.abs(window.innerWidth - width) > 50) setWidth(window.innerWidth);
      if (Math.abs(window.innerHeight - height) > 50) setHeight(window.innerWidth);
    };
  },[width]);

  const token = localStorage.getItem('token');

  if (!id && token) return (
      <div className="loading-container">
        <Loader type="Oval" color="#363e47" height={40} width={40} />
      </div>
  );

  if (!id) return <Login/>;
  if (!exp) return  <Login/>;

  const currentTime = Date.now() / 1000;
  if ( exp < currentTime) {
    localStorage.removeItem('token');
    dispatch(User.USER_LOGOUT);
    return <Login/>
  }

  let View = () => {
    if (window.innerWidth > 1241) return <Desktop/>;
    if (window.innerWidth > 991) return <Tablet/>;
    else return <Phone/>;
  };

  return <View/>;
}

export default App;
