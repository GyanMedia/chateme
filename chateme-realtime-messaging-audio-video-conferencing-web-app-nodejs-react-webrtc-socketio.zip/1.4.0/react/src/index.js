import React from 'react';
import ReactDOM from 'react-dom';
import UIkit from 'uikit';
import Icons from 'uikit/dist/js/uikit-icons';
import './index.sass';
import App from './App';
import {BrowserRouter} from 'react-router-dom';
import * as serviceWorker from './serviceWorker';
import {createStore, applyMiddleware, compose} from "redux";
import createSagaMiddleware from "redux-saga";
import {Provider} from "react-redux";

import rootReducer from "./reducers";
import watcherSaga from "./sagas";
import adapter from 'webrtc-adapter';

// device detection
const isMobile = () => {
    if (navigator.userAgent.match(/Mobi/)) return true;
    if ('screen' in window && window.screen.width < 1366) return true;
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    return !!(connection && connection.type === 'cellular');
};
window.isMobile = isMobile();

// create the saga middleware
const sagaMiddleware = createSagaMiddleware();

// dev tools middleware
const reduxDevTools =
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__();

// create a redux store with our reducer above and middleware
let store = createStore(
  rootReducer,
  reduxDevTools ? compose(applyMiddleware(sagaMiddleware), reduxDevTools) : applyMiddleware(sagaMiddleware)
);

// run the saga
sagaMiddleware.run(watcherSaga);


// Loading UIkit Icons plugin.
UIkit.use(Icons);

ReactDOM.render(
  <Provider store={store}>
    <BrowserRouter>
      <App/>
    </BrowserRouter>
  </Provider>,
  document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
