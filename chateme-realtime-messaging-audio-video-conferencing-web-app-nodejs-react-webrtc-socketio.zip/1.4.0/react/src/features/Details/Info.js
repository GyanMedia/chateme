import React from 'react';
import './Info.sass';
import logo from '../../assets/logo.png';
import {useSelector} from "react-redux";
import Config from '../../config';

const Details = () => {
    const room = useSelector(state => state.room);
    const user = useSelector(state => state.user);

    let other = {
        firstName: 'A', lastName: 'A'
    };

    if (!room.isGroup && room.people) {
        room.people.forEach(person => {
            if (person._id !== user.id) other = person;
        });
    }

    return (
        <div className="info">
            <div className="top">
                <div className="logo">
                    <img src={logo} alt="Picture" />
                </div>
                <div className="text">
                    Welcome to {Config.appName || 'Clover'}!<br/><br/>
                    {Config.appName || 'Clover'} is a messaging app that enables real-time messaging, audio and video calls, groups and conferencing.
                </div>
            </div>
            <div className="text">
                Copyright &copy; {Config.brand || 'Honeyside'}
            </div>
        </div>
    );
};

export default Details;
