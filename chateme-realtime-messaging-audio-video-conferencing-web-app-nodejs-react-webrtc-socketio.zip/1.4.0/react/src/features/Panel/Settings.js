import React, {useRef, useState} from 'react';
import {
    FiEdit2
} from "react-icons/fi";
import Actions from "../../variables/actions/Actions";
import {useDispatch, useSelector} from 'react-redux';
import User from "../../variables/actions/User";
import View from "../../variables/actions/View";
import Views from "../../variables/Views";
import Config from "../../config";

const Settings = () => {
    const dispatch = useDispatch();

    const images = useSelector(state => state.images);
    const ref = useSelector(state => state.images.ref);
    const user = useSelector(state => state.user);

    const fileInput = useRef(null);

    const [pictureRef, setPictureRef] = useState(0);

    const changePicture = image => {
        setPictureRef(ref);
        dispatch({type: Actions.UPLOAD_IMAGE, image: image, crop: 'square', ref: ref, next: {type: Actions.CHANGE_PICTURE, ref}});
    };

    const Picture = () => {
        if (user.picture)
            return <img src={`${Config.url || ''}/api/images/${user.picture.shieldedID}/256`} alt="Picture" className="picture"/>;
        else
            return <div className="img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div>;
    };

    const navigate = view => dispatch({ type: View.NAVIGATE, nav: view, panel: view });

    return (
        <div className="list-wrapper">
            <div className="list">
                <input
                    className="file-input"
                    type="file"
                    ref={fileInput}
                    accept="image/*"
                    onChange={e => changePicture(e.target.files[0])}
                />
                <div className="picture" onClick={() => fileInput && fileInput.current && fileInput.current.click()}>
                    <Picture/>
                    <div className="overlay">
                        <div className="text"><FiEdit2/></div>
                    </div>
                </div>
                <button className="uk-margin-remove-bottom uk-button uk-button-secondary" onClick={() => navigate(Views.CREATE_GROUP)}>Remove Picture</button>
                <button className="uk-margin-remove-bottom uk-button uk-button-secondary uk-button-large" onClick={() => dispatch({ type: User.USER_LOGOUT })}>Logout</button>
                <button className="uk-margin-small uk-button uk-button-primary uk-button-large" onClick={() => navigate(Views.CREATE_GROUP)}>Create Group</button>
            </div>
        </div>
    );
};

export default Settings;

