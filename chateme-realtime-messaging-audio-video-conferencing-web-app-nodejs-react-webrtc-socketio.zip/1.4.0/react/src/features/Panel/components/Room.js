import React from 'react';
import {useDispatch, useSelector} from "react-redux";
import Actions from "../../../variables/actions/Actions";
import {FiUser, FiUsers} from "react-icons/fi";
import Config from "../../../config";

const Room = ({room}) => {
    let { people, lastMessage } = room;

    const dispatch = useDispatch();

    const user = useSelector(state => state.user);
    const status = useSelector(state => state.status);

    let other = {};

    people.forEach(person => {
        if (user.id !== person._id) other = person;
    });

    if (!other.firstName) {
        other = { ...other, firstName: 'Deleted', lastName: 'User' };
    }

    let text = '';

    if (!lastMessage && room.isGroup) text = 'New group created.';

    if (!lastMessage) lastMessage = {};

    if (lastMessage.author === user.id) text += 'You: ';

    text += lastMessage.type === 'image' ? 'Sent a picture.' : (lastMessage.content || '');

    const Picture = ({picture, user}) => {
        if (picture)
            return <img src={`${Config.url || ''}/api/images/${picture.shieldedID}/256`} alt="Picture" />;
        else
            return <div className="img">{ room.isGroup ? room.title.substr(0, 1) : `${user.firstName.substr(0,1)}${user.lastName.substr(0,1)}`}</div>;
    };

    const getClass = () => {
        if (status.online.includes(other._id)) return 'online';
        if (status.away.includes(other._id)) return 'away';
        if (status.busy.includes(other._id)) return 'busy';
        return 'offline';
    };

    let title = room.isGroup ? room.title : `${other.firstName} ${other.lastName}`;
    title = title.length > 24 ? `${title.substr(0, 21)}...` : title;

    return (
        <div className="entry" onClick={() => dispatch({type: Actions.JOIN_ROOM, roomID: room._id})}>
            <div className="picture">
                <Picture picture={room.isGroup ? room.picture : other.picture} user={other} />
                {!room.isGroup && <div className={`status ${getClass()}`} />}
            </div>
            <div className="text">
                <div className="title">{title}</div>
                <div className="message">{text.substr(0, 20)}{text.length > 20 && '...'}</div>
            </div>
            <div className="indicator room">
                {room.isGroup ? <FiUsers/> : <FiUser/>}
            </div>
        </div>
    );
};

export default Room;
