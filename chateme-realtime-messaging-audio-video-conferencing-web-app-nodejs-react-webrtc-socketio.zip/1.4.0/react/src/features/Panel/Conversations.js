import React, {useEffect, useRef, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";
import Room from "./components/Room";
import Actions from "../../variables/actions/Actions";

const Conversations = () => {
    const dispatch = useDispatch();

    const rooms = useSelector(state => state.panel.rooms);
    const roomsNumber = useSelector(state => state.panel.rooms.length);
    const favorites = useSelector(state => state.user.favorites);
    const firstRoomID = useSelector(state => state.panel.rooms.length > 0 ? state.panel.rooms[state.panel.rooms.length - 1].lastUpdate : null);

    const scrollContainer = useRef(null);

    const [scrollHeight, setScrollHeight] = useState(0);
    const [tab, setTab] = useState(0);

    useEffect(() => {
        if (scrollContainer.current.scrollTop === 0) scrollContainer.current.scrollTop = scrollHeight
    }, [roomsNumber]);

    const onScroll = () => {
        setScrollHeight(scrollContainer.current.scrollHeight);
        if (scrollContainer.current.scrollTop >= (scrollContainer.current.scrollHeight - scrollContainer.current.offsetHeight))
            dispatch({type: Actions.MORE_ROOMS, roomID: firstRoomID});
    };

    const Rooms = (tab ? favorites : rooms).map(room => {
        return <Room room={room} key={room._id} />
    });

    const Notice = () => {
        if (!tab && rooms.length === 0) return (
            <div className="notice-text">
                There are no rooms.<br/>Search for someone to start a conversation!
            </div>
        );
        if (tab && favorites.length === 0) return (
            <div className="notice-text">
                You have no favorites.<br/>Add rooms or people to favorites to find them faster!
            </div>
        );
        return null;
    };

    return (
        <div className="list-wrapper">
            <ul className="uk-tab-bottom panel-tabs" data-uk-tab={true}>
                <li className="uk-active" onClick={() => setTab(0)}><a href="#">Rooms</a></li>
                <li onClick={() => setTab(1)}><a href="#">Favorites</a></li>
            </ul>
            <Notice/>
            <div className="list" ref={scrollContainer} onScroll={onScroll} >
                {Rooms}
            </div>
        </div>
    );
};

export default Conversations;
