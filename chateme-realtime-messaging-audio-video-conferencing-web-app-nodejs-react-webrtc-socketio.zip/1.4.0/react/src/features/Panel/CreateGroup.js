import React, {useRef, useState} from 'react';
import './Panel.sass';
import {useDispatch, useSelector} from "react-redux";
import {
    FiEdit2,
    FiPlusCircle,
    FiMinusCircle,
} from "react-icons/fi";
import View from "../../variables/actions/View";
import Views from "../../variables/Views";
import Actions from "../../variables/actions/Actions";
import Config from "../../config";

const Selection = ({type}) => {
    const dispatch = useDispatch();

    const ref = useSelector(state => state.images.ref);
    const picture = useSelector(state => state.selection.picture);
    const people = useSelector(state => state.selection.people);
    const id = useSelector(state => state.user.id);

    const fileInput = useRef(null);

    const [pictureRef, setPictureRef] = useState(0);
    const [title, setTitle] = useState('');
    const [error, setError] = useState(false);

    const GroupPicture = ({picture}) => {
        if (picture)
            return <img src={`${Config.url || ''}/api/images/${picture.shieldedID}/256`} alt="Picture" className="picture"/>;
        else
            return <div className="img">G</div>;
    };

    const changePicture = image => {
        setPictureRef(ref);
        dispatch({type: Actions.UPLOAD_IMAGE, image: image, crop: 'square', ref: ref, next: {type: Actions.SELECTION_CHANGE_PICTURE, ref}});
    };

    const createGroup = e => {
        e.preventDefault();
        if (title.length === 0) return setError(true);
        setError(null);
        dispatch({ type: Actions.GROUP_CREATE, people: [...people, id], title, picture });
    };

    return (
        <div className="list-wrapper">
            <div className="list">
                <input
                    className="file-input"
                    type="file"
                    ref={fileInput}
                    accept="image/*"
                    onChange={e => changePicture(e.target.files[0])}
                />
                <div className="picture" onClick={() => fileInput && fileInput.current && fileInput.current.click()}>
                    <GroupPicture picture={picture} />
                    <div className="overlay">
                        <div className="text"><FiEdit2/></div>
                    </div>
                </div>
                <input className="group-name" type="text" placeholder="Group title..." onChange={e => setTitle(e.target.value)} />
                <div className="selection-text error" hidden={!error}>
                    Group title required!
                </div>
                <button className="uk-margin-small uk-button uk-button-large uk-button-primary" onClick={createGroup}>Create Group</button>
                <button className="uk-margin-remove-top uk-button uk-button-secondary" onClick={() => dispatch({ type: View.NAVIGATE, nav: Views.CREATE_GROUP })}>Back</button>
            </div>
        </div>
    );
};

export default Selection;
