import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import Input from "./components/Input";
import Actions from "../../variables/actions/Actions";
import Config from "../../config";

const Admin = () => {
    const dispatch = useDispatch();

    const [user, setUser] = useState(null);
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [repeatPassword, setRepeatPassword] = useState('');

    const admin = useSelector(state => state.admin);
    const view = useSelector(state => state.admin.view);
    const search = useSelector(state => state.search);

    let list;

    const Picture = ({user}) => {
        if (user.picture)
            return <img src={`${Config.url || ''}/api/images/${user.picture.shieldedID}/256`} alt="Picture" />;
        else
            return <div className="img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div>;
    };

    const notice = () => {
        if (typeof search.users !== 'object' || search.users.length === 0) return (
            <div className="notice-text">
                There are no results matching {search.text}.
            </div>
        );
        else return null;
    };

    const manage = (user, view) => {
        dispatch({type: view});
        setUser(user);
        if (view === Actions.ADMIN_VIEW_CREATE) {
            setUsername(null);
            setEmail(null);
            setFirstName(null);
            setLastName(null);
        }
        if (view === Actions.ADMIN_VIEW_UPDATE) {
            setUsername(user.username);
            setEmail(user.email);
            setFirstName(user.firstName);
            setLastName(user.lastName);
        }
        setPassword(null);
        setRepeatPassword(null);
    };

    const createUser = e => {
        e.preventDefault();
        dispatch({type: Actions.ADMIN_USER_CREATE, username, email, password, repeatPassword, firstName, lastName, search: search.text });
    };

    const updateUser = e => {
        e.preventDefault();
        dispatch({type: Actions.ADMIN_USER_UPDATE, username, email, password, repeatPassword, firstName, lastName, search: search.text, user });
    };

    const deleteUser = (email, username) => dispatch({type: Actions.ADMIN_USER_DELETE, email, username, search: search.text });

    if (view === 'CREATE' || (view === 'EDIT' && user)) {
        return (
            <div className="list-wrapper">
                <div className="list">
                    <div className="uk-flex uk-flex-column uk-flex-center uk-flex-middle admin-delete">
                        <div className="uk-text-center uk-margin-small-bottom">{view === 'EDIT' ? `Currently editing @${user.username}` : 'Create new user'}</div>
                        <form className="uk-flex uk-flex-column uk-flex-center uk-flex-middle" onSubmit={e => view === 'EDIT' ? updateUser(e) : createUser(e)}>
                            <Input icon="user" placeholder="Username" type="text" required={true} value={username} onChange={e => setUsername(e.target.value)} />
                            {admin.error && admin.error.username && <div className="admin-form-error">{admin.error.username}</div>}
                            <Input icon="mail" placeholder="Email" type="email" required={true} value={email} onChange={e => setEmail(e.target.value)} />
                            {admin.error && admin.error.email && <div className="admin-form-error">{admin.error.email}</div>}
                            <Input icon="pencil" placeholder="First Name" type="text" required={true} value={firstName} onChange={e => setFirstName(e.target.value)} />
                            {admin.error && admin.error.firstName && <div className="admin-form-error">{admin.error.firstName}</div>}
                            <Input icon="pencil" placeholder="Last Name" type="text" required={true} value={lastName} onChange={e => setLastName(e.target.value)} />
                            {admin.error && admin.error.lastName && <div className="admin-form-error">{admin.error.lastName}</div>}
                            <Input icon="lock" placeholder="Password" type="password" required={view === 'CREATE'} value={password} onChange={e => setPassword(e.target.value)} />
                            {admin.error && admin.error.password && <div className="admin-form-error">{admin.error.password}</div>}
                            <Input icon="lock" placeholder="Repeat Password" type="password" required={view === 'CREATE'} value={repeatPassword} onChange={e => setRepeatPassword(e.target.value)} />
                            {admin.error && admin.error.repeatPassword && <div className="admin-form-error">{admin.error.repeatPassword}</div>}
                            <button type="submit" className="uk-button uk-button-primary uk-margin-top">{view === 'EDIT' ? 'Update' : 'Create'} User</button>
                            <button className="uk-button uk-button-secondary" onClick={() => manage(null, Actions.ADMIN_VIEW_CANCEL)}>Cancel</button>
                            {view === 'EDIT' && <div className="uk-text-center notice">Leave password blank if you don't want to change it.</div>}
                        </form>
                    </div>
                </div>
            </div>
        )
    }

    if (view === 'DELETE' && user) {
        return (
            <div className="list-wrapper">
                <div className="list">
                    <div className="uk-flex uk-flex-column uk-flex-center uk-flex-middle admin-delete">
                        <div className="uk-text-center">Are you sure you want to delete user @{user.username}?</div>
                        <button className="uk-button uk-button-primary uk-margin-top" onClick={() => deleteUser(user.email, user.username)}>Delete User</button>
                        <button className="uk-button uk-button-secondary" onClick={() => manage(null, Actions.ADMIN_VIEW_CANCEL)}>Cancel</button>
                        <div className="uk-text-center notice">Messages sent by the user will not be deleted. A deleted user can not be recovered.</div>
                    </div>
                </div>
            </div>
        )
    }

    if (typeof search.users === 'object') {
        list = search.users.map(user => {
            return (
                <div key={user._id} className="admin-entry">
                    <div className="picture">
                        <Picture user={user} />
                    </div>
                    <div className="text">
                        <div className="message">Email: <span className="white">{user.email}</span></div>
                        <div className="message">First name: <span className="white">{user.firstName}</span></div>
                        <div className="message">Last name: <span className="white">{user.lastName}</span></div>
                        <div className="message">Username: <span className="white">{user.username}</span></div>
                        <div className="message">
                            Actions: <a className="edit" onClick={() => manage(user, Actions.ADMIN_VIEW_UPDATE)}>Edit</a> - <a className="delete" onClick={() => manage(user, Actions.ADMIN_VIEW_DELETE)}>Delete</a>
                        </div>
                    </div>
                </div>
            )
        })
    }

    return (
        <div className="list-wrapper">
            <div className="list">
                <button className="uk-margin-remove uk-button uk-button-secondary" onClick={() => manage(null, Actions.ADMIN_VIEW_CREATE)}>CREATE NEW USER</button>
                {list}
                {notice()}
            </div>
            <div className="selection-text" hidden={!['CREATED','UPDATED','DELETED'].includes(admin.status)}>
                {admin.status === 'CREATED' && <div>User {admin.username} has been created.</div>}
                {admin.status === 'UPDATED' && <div>User {admin.username} has been updated.</div>}
                {admin.status === 'DELETED' && <div>User {admin.username} has been deleted.</div>}
            </div>
        </div>
    );
};

export default Admin;

