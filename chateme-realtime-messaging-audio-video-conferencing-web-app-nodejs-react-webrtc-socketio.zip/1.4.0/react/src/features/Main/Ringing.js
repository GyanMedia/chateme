import React from 'react';
import './Ringing.sass';
import {
    FiPhone,
    FiVideo,
    FiPhoneOff,
} from "react-icons/fi";
import {useDispatch, useSelector} from "react-redux";
import Actions from "../../variables/actions/Actions";
import Config from "../../config";

const Ringing = ({direction}) => {
    const dispatch = useDispatch();

    const session = useSelector(state => state.rtc.session);
    const displayName = session && session.remoteIdentity && session.remoteIdentity.displayName ? session.remoteIdentity.displayName : 'Anonymous';
    let user = useSelector(state => state.rtc.user);
    let {group, isGroup} = useSelector(state => state.rtc.room);
    const video = useSelector(state => state.rtc.video);

    (!user || !user.firstName) && (user = {
        firstName: 'Anonymous',
        lastName: 'Anonymous',
    });

    const getSubStr = () => {
        if (isGroup) return group.title.substr(0,1);
        else return `${user.firstName.substr(0,1)}${user.lastName.substr(0,1)}`;
    };

    const Picture = () => {
        if (isGroup ? group.picture : user.picture)
            return <img src={`${Config.url || ''}/api/images/${isGroup ? group.picture.shieldedID : user.picture.shieldedID}/256`} alt="Picture" className="picture"/>;
        else
            return <div className="wrapper"><div className="img">{getSubStr()}</div></div>;
    };

    return (
        <div className="incoming">
            <div className="user">
                <div className="name">
                    {isGroup ? group.title : (`${user.firstName} ${user.lastName}`)}
                </div>
                <div className="text">{direction === 'incoming' ? 'Incoming' : 'Outgoing'} {video ? 'Videocall' : 'Call'}</div>
                <div className="dots"><span>.</span><span>.</span><span>.</span></div>
            </div>
            <div className="profile">
                <Picture/>
            </div>
            <div className="controls">
                {direction === 'incoming' &&
                    <div className="control green" onClick={() => dispatch({type: Actions.RTC_ACCEPT, video: true, audio: true})}>
                        <FiVideo/>
                    </div>
                }
                {direction === 'incoming' &&
                    <div className="control green" onClick={() => dispatch({type: Actions.RTC_ACCEPT, video: false, audio: true})}>
                        <FiPhone/>
                    </div>
                }
                <div className="control red" onClick={() => dispatch({type: Actions.RTC_CLOSE})}>
                    <FiPhoneOff/>
                </div>
            </div>
        </div>
    );
};

export default Ringing;
