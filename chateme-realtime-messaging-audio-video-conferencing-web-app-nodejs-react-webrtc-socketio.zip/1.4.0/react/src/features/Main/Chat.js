import React, {useEffect, useRef, useState} from 'react';
import './Main.sass';
import {useDispatch, useSelector} from "react-redux";
import Messages from "./components/Messages";
import Actions from "../../variables/actions/Actions";

const Chat = () => {
    const messagesEnd = useRef(null);
    const chat = useRef(null);

    const dispatch = useDispatch();

    const roomID = useSelector(state => state.room._id);
    const firstMessageID = useSelector(state => state.room.firstMessageID);
    const lastMessageID = useSelector(state => state.room.lastMessageID);
    const messagesNumber = useSelector(state => state.room.messages.length);

    const [scrollHeight, setScrollHeight] = useState(0);

    useEffect(() => {
        if (chat.current.scrollTop === 0) chat.current.scrollTop = chat.current.scrollHeight - scrollHeight
    }, [messagesNumber]);


    useEffect(() => {
        messagesEnd.current.scrollIntoView();
    }, [lastMessageID]);

    const onScroll = () => {
        setScrollHeight(chat.current.scrollHeight);
        if (chat.current.scrollTop === 0) dispatch({type: Actions.MORE_MESSAGES, roomID, messageID: firstMessageID});
    };

    return (
        <div className="chat" ref={chat} onScroll={onScroll}>
            <Messages/>
            <div style={{ float:"left", clear: "both" }} ref={messagesEnd} />
        </div>
    );
};

export default Chat;
