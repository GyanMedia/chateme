import React, {useState} from 'react';
import './Session.sass';
import {
    FiMaximize,
    FiMic,
    FiMicOff,
    FiMinimize,
    FiPhoneOff,
    FiVideo,
    FiVideoOff,
    FiUserPlus,
    FiMonitor,
    FiXOctagon,
    FiGrid,
    FiColumns,
} from "react-icons/fi";
import {useDispatch, useSelector} from "react-redux";
import Actions from "../../variables/actions/Actions";
import RemoteVideo from "./components/RemoteVideo";
import LocalVideo from "./components/LocalVideo";
import AudioStreams from "./components/AudioStreams";
import View from "../../variables/actions/View";
import Views from "../../variables/Views";

const Session = () => {
    const dispatch = useDispatch();

    const audio = useSelector(state => state.rtc.audio);
    const video = useSelector(state => state.rtc.video);
    const localStream = useSelector(state => state.rtc.localStream);
    const screenSharing = useSelector(state => state.rtc.screenSharing);

    const [isMaximized, setMaximized] = useState(true);

    const maximize = e => {
        e.preventDefault();
        setMaximized(!isMaximized);
    };

    const navigate = view => dispatch({ type: View.NAVIGATE, nav: view, panel: view });

    return (
        <div className="session">
            <RemoteVideo isMaximized={isMaximized} />
            <LocalVideo/>
            <AudioStreams/>
            <div className="controls">
                <div className="control" onClick={() => dispatch({type: Actions.RTC_SCREEN_SHARE})} style={{visibility: 'hidden'}}>
                    {screenSharing ? <FiXOctagon/> : <FiMonitor/>}
                </div>
                {
                    localStream.getVideoTracks().length > 0 &&
                    <div className="control" onClick={() => dispatch({type: Actions.RTC_SWITCH_VIDEO, video: !video})}>
                        {video ? <FiVideo/> : <FiVideoOff/>}
                    </div>
                }
                <div className="control" onClick={() => dispatch({ type: Actions.RTC_SWITCH_AUDIO, audio: !audio })}>
                    {audio ? <FiMic/> : <FiMicOff/>}
                </div>
                <div className="close" onClick={() => dispatch({ type: Actions.RTC_CLOSE })}>
                    <FiPhoneOff/>
                </div>
                <div className="control" onClick={() => navigate(Views.RTC_ADD_USERS)}>
                    <FiUserPlus/>
                </div>
                <div className="control" onClick={maximize}>
                    {isMaximized ? <FiMaximize/> : <FiMinimize/>}
                </div>
                <div className="control" onClick={() => dispatch({type: screenSharing ? Actions.RTC_SCREEN_SHARE_STOP : Actions.RTC_SCREEN_SHARE})}>
                    {screenSharing ? <FiXOctagon/> : <FiMonitor/>}
                </div>
            </div>
        </div>
    );
};

export default Session;
