import React, {useState} from 'react';
import './Session.sass';
import {
    FiMaximize,
    FiMic,
    FiMicOff,
    FiMinimize,
    FiPhoneOff,
    FiVideo,
    FiVideoOff,
    FiUserPlus,
} from "react-icons/fi";
import {useDispatch, useSelector} from "react-redux";
import Actions from "../../variables/actions/Actions";
import RemoteVideo from "./components/RemoteVideo";
import LocalVideo from "./components/LocalVideo";
import AudioOnly from "./components/AudioOnly";

const Session = () => {
    const dispatch = useDispatch();

    const audio = useSelector(state => state.rtc.audio);
    const video = useSelector(state => state.rtc.video);

    const [isMaximized, setMaximized] = useState(true);

    const maximize = e => {
        e.preventDefault();
        setMaximized(!isMaximized);
    };

    return (
        <div className="session">
            <RemoteVideo isMaximized={isMaximized} />
            <LocalVideo/>
            <div className="controls">
                <div className="control" onClick={() => dispatch({ type: Actions.RTC_SWITCH_VIDEO })}>
                    {video ? <FiVideo/> : <FiVideoOff/>}
                </div>
                <div className="control" onClick={() => dispatch({ type: Actions.RTC_SWITCH_AUDIO })}>
                    {audio ? <FiMic/> : <FiMicOff/>}
                </div>
                <div className="close" onClick={() => dispatch({ type: Actions.RTC_CLOSE })}>
                    <FiPhoneOff/>
                </div>
                <div className="control" onClick={() => dispatch({ type: Actions.RTC_CLOSE })}>
                    <FiUserPlus/>
                </div>
                <div className="control" onClick={maximize}>
                    {isMaximized ? <FiMaximize/> : <FiMinimize/>}
                </div>
            </div>
        </div>
    );
};

export default Session;
