import React from 'react';
import './Home.sass';
import {useSelector} from "react-redux";
import Config from "../../config";

const Home = () => {
    const user = useSelector(state => state.user);

    const Picture = () => {
        if (user.picture)
            return <img src={`${Config.url || ''}/api/images/${user.picture.shieldedID}/256`} alt="Picture" className="picture"/>;
        else
            return <div className="img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div>;
    };

    return (
        <div className="home">
            <div className="overlay"/>
            <div className="welcome-text">
                Welcome, {user.firstName}
            </div>
            <div className="profile">
                <Picture/>
            </div>
            <div className="text">
                Search for someone to start a conversation,<br/>Add contacts to your favorites to reach them faster
            </div>
        </div>
    );
};

export default Home;
