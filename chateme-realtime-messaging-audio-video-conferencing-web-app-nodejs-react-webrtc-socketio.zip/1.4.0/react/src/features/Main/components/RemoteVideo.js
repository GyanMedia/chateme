import React, {useEffect, useRef} from 'react';
import {useSelector} from "react-redux";
import Video from './Video';
import AudioOnly from "./AudioOnly";

const RemoteVideo = ({isMaximized}) => {
    const {audioStreams, videoStreams} = useSelector(state => state.rtc);

    let streams = [];

    videoStreams.forEach(stream => {
        console.log('track enabled', stream.getVideoTracks()[0])
        if (stream.getVideoTracks()[0].enabled) streams.push(stream);
    });

    if (streams.length === 0) return <AudioOnly stream={audioStreams[0]} />;

    let side = Math.ceil(Math.sqrt(streams.length));

    let rows = [];
    let row = [];

    streams.forEach((stream, key) => {
        if (row.length === side) {
            rows.push(
                <div className="video-row" key={key}>
                    {row}
                </div>
            );
            row = [];
        }
        row.push(
            <div className="video-wrapper">
                <Video source="remote" stream={stream} isMaximized={isMaximized} muted={false} />
            </div>
        );
    });

    if (row.length > 0) {
        rows.push(
            <div className="video-row">
                {row}
            </div>
        );
    }

    return (
        <div className="video-container">
            {rows}
        </div>
    );
};

export default RemoteVideo;
