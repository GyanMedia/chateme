import React from 'react';
import {useSelector} from "react-redux";
import Video from './Video';
import './LocalAudio.sass';

const LocalVideo = () => {
    const {localStream} = useSelector(state => state.rtc);

    const isVideo = localStream && localStream.getVideoTracks().length > 0;
    const user = useSelector(state => state.user);

    if (isVideo && localStream.getVideoTracks()[0].enabled) return (
        <div className="local-video-wrapper">
            <Video source="local" stream={localStream} isMaximized={true} muted={true} />
        </div>
    );

    const Picture = () => {
        if (user.picture)
            return <img src={`/api/images/${user.picture.shieldedID}/256`} alt="Picture" className="local-audio-picture"/>;
        else
            return <div className="local-audio-wrapper"><div className="local-audio-img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div></div>;
    };

    return (
        <div className="local-audio">
            <Picture/>
        </div>
    );
};

export default LocalVideo;
