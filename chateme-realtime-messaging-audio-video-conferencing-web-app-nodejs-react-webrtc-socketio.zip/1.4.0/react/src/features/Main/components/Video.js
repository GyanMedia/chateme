import React, {useEffect, useRef} from 'react';

const Video = ({source, stream, isMaximized, muted}) => {
    const ref = useRef(null);

    useEffect(() => {
        console.log(typeof stream);
        ref.current.srcObject = stream;
    }, [stream]);

    return (
        <video
            className={source === 'remote' ? 'remote-video' : 'local-video'}
            ref={ref}
            autoPlay={true}
            style={{objectFit: isMaximized ? 'cover' : 'contain'}}
            muted={muted}
        />
    );
};

export default Video;
