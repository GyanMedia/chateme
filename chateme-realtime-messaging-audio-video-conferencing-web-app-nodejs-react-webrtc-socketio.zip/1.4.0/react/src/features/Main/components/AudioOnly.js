import React, {useEffect, useRef} from 'react';
import './AudioOnly.sass';
import {useDispatch, useSelector} from "react-redux";
import Clock from './Clock';
import Config from "../../../config";

const AudioOnly = () => {
    const ref = useRef(null);

    const session = useSelector(state => state.rtc.session);
    const displayName = session && session.remoteIdentity && session.remoteIdentity.displayName ? session.remoteIdentity.displayName : 'Anonymous';
    let user = useSelector(state => state.rtc.user);

    !user && (user = {
        firstName: 'Anonymous',
        lastName: 'Anonymous',
    });

    const Picture = () => {
        if (user.picture)
            return <img src={`${Config.url || ''}/api/images/${user.picture.shieldedID}/256`} alt="Picture" className="audio-picture"/>;
        else
            return <div className="audio-wrapper"><div className="audio-img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div></div>;
    };

    return (
        <div className="audio-only">
            <div className="audio-user">
                <div className="audio-name">
                    {user._id ? (`${user.firstName} ${user.lastName}`) : displayName}
                </div>
                <div className="audio-text">Audio Only</div>
                <Clock/>
            </div>
            <div className="audio-profile">
                <Picture/>
            </div>
            <div className="audio-controls"/>
        </div>
    );
};

export default AudioOnly;
