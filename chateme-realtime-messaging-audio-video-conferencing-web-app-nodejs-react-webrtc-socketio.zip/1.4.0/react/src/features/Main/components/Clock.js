import React, {useState, useEffect} from 'react';

const Clock = () => {
    const [time, setTime] = useState(0);

    useEffect(() => {
       let interval = setInterval(() => setTime(time + 1), 1000);
       return () => {
           clearInterval(interval);
       }
    });

    const minutes = Math.floor(time / 60);

    const minutesString = minutes > 9 ? minutes.toString() : `0${minutes}`;

    const seconds = time - minutes * 60;

    const secondsString = seconds > 9 ? seconds.toString() : `0${seconds}`;

    return <div className="time">{minutesString}:{secondsString}</div>;
};

export default Clock;
