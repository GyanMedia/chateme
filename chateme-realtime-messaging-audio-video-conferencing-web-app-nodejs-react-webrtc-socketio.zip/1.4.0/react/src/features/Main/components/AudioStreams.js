import React, {useEffect, useRef} from 'react';
import './AudioOnly.sass';
import {useSelector} from "react-redux";

const AudioElement = ({stream}) => {
    const video = useRef(null);

    useEffect(() => {
        video.current.srcObject = stream;
    }, [stream]);

    return (
        <video ref={video} autoPlay />
    );
};

const AudioStreams = () => {
    const streams = useSelector(state => state.rtc.audioStreams);

    const audioElements = streams.map(stream => <AudioElement key={stream.id} stream={stream} />);

    return (
        <div hidden>
            {audioElements}
        </div>
    );
};

export default AudioStreams;
