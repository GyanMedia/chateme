import React from 'react';
import Config from '../../../config';

const Credits = () => (
    <span> - <a
        data-uk-tooltip="Special thanks and open source resources in use"
        data-uk-toggle="target: .toggle-credits ;animation: uk-animation-fade"
    >Credits</a></span>
);

const Copyright = () => {
  return (
    <div className="uk-position-bottom-center uk-position-small uk-visible@m uk-position-z-index">
          <span className="uk-text-small uk-text-muted">© 2020 {Config.brand || 'Honeyside'}{Config.showCredits && <Credits/>}</span>
    </div>
  );
};

export default Copyright;
