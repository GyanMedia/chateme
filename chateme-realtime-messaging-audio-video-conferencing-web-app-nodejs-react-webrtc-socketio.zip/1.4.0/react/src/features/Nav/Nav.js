import React from 'react';
import './Nav.sass';
import {useDispatch, useSelector} from "react-redux";
import {
    FiCpu,
    FiPhone,
    FiMessageCircle,
    FiSearch,
    FiSettings,
    FiStar,
} from "react-icons/fi";
import Views from "../../variables/Views";
import View from "../../variables/actions/View";
import combine from 'classnames';
import Actions from "../../variables/actions/Actions";
import Config from "../../config";

const Nav = ({mobile}) => {
    const dispatch = useDispatch();

    const view = useSelector(state => state.view.nav);
    const mobileView = useSelector(state => state.view.mobile);
    const user = useSelector(state => state.user);
    const peerConnection = useSelector(state => state.rtc.peerConnection);
    const rtcStatus = useSelector(state => state.rtc.status);
    const status = useSelector(state => state.status);

    const navigate = view => dispatch({ type: View.NAVIGATE, nav: view, panel: view });
    const showHome = view => dispatch({ type: Actions.SHOW_HOME });

    const Picture = () => {
        if (user.picture)
            return <img src={`${Config.url || ''}/api/images/${user.picture.shieldedID}/256`} alt="Picture" className="picture"/>;
        else
            return <div className="img">{user.firstName.substr(0,1)}{user.lastName.substr(0,1)}</div>;
    };

    const getClass = () => {
        if (status.online.includes(user.id)) return 'online';
        if (status.away.includes(user.id)) return 'away';
        if (status.busy.includes(user.id)) return 'busy';
        return 'offline';
    };

    return (
            <div className="nav">
                <div className="profile" onClick={() => showHome()}>
                    <Picture/>
                    <div className={`status ${getClass()}`} />
                </div>
                <div className={combine('button first', { active: view === Views.CHAT && (mobileView !== Views.WELCOME || !mobile) })} onClick={() => navigate(Views.CHAT)}>
                    <FiMessageCircle/>
                </div>
                <div className={combine('button', { active: view === Views.FAVORITES && (mobileView !== Views.WELCOME || !mobile) })} onClick={() => navigate(Views.FAVORITES)} hidden>
                    <FiStar/>
                </div>
                <div className={combine('button', { active: [Views.SETTINGS, Views.CREATE_GROUP, Views.CREATE_GROUP_2, Views.EDIT_GROUP, Views.RTC_GROUP_CREATE, Views.RTC_ADD_USERS].includes(view) && (mobileView !== Views.WELCOME || !mobile) })} onClick={() => navigate(Views.SETTINGS)}>
                    <FiSettings/>
                </div>
                {
                    rtcStatus &&
                    <div className={combine('button', {active: (view === Views.SESSION || view === Views.INCOMING || view === Views.OUTGOING) && (mobileView !== Views.WELCOME || !mobile) })}
                         onClick={() => navigate(rtcStatus)}>
                        <FiPhone/>
                    </div>
                }

                <div className={combine('button', {active: view === Views.SEARCH && (mobileView !== Views.WELCOME || !mobile) })}
                     onClick={() => navigate(Views.SEARCH)}>
                    <FiSearch/>
                </div>

                {
                    ['root', 'admin'].includes(user.level) &&
                    <div
                        className={combine('button', {active: view === Views.ADMIN && (mobileView !== Views.WELCOME || !mobile)})}
                        onClick={() => navigate(Views.ADMIN)}>
                        <FiCpu/>
                    </div>
                }
            </div>
    );
};

export default Nav;
