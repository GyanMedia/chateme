import { call, put } from "redux-saga/effects";
import jwtDecode from 'jwt-decode';
import User from "../variables/actions/User";

import axios from "axios";

const createRoom = counterpart => {
    window.socket.emit('create-room', { counterpart });
};

const joinRoom = roomID => {
    window.socket.emit('join-room', { roomID });
};

const listRooms = () => {
    window.socket.emit('list-rooms', {});
};

const moreMessages = (roomID, messageID) => {
    window.socket.emit('more-messages', { roomID, messageID });
};

const moreImages = (roomID, messageID) => {
    window.socket.emit('more-images', { roomID, messageID });
};

const createGroup = (people, title, picture) => {
    window.socket.emit('create-group', { people, title, picture });
};

const moreRooms = roomID => {
    window.socket.emit('more-rooms', { roomID });
};

// worker saga: makes the api call when watcher saga sees the action
export function* createRoomSaga(action) {
    yield call(createRoom, action.counterpart);
}

export function* joinRoomSaga(action) {
    yield call(joinRoom, action.roomID);
}

export function* listRoomSaga(action) {
    yield call(listRooms);
}

export function* moreMessagesSaga(action) {
    yield call(moreMessages, action.roomID, action.messageID);
}

export function* moreImagesSaga(action) {
    yield call(moreImages, action.roomID, action.messageID);
}

export function* createGroupSaga(action) {
    yield call(createGroup, action.people, action.title, action.picture );
}

export function* moreRoomsSaga(action) {
    yield call(moreRooms, action.roomID);
}
