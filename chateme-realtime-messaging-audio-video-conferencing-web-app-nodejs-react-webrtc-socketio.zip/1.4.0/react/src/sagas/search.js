import { call, put } from "redux-saga/effects";
import Actions from '../variables/actions/Actions';
import jwtDecode from 'jwt-decode';
import User from "../variables/actions/User";

import axios from "axios";

const emitSearch = search => {
  window.socket.emit('search', { search })
};

// worker saga: makes the api call when watcher saga sees the action
export function* searchSaga(action) {
  /*if (action.search.length === 0) {
    put({type: Actions.SEARCH_RESULT, data: {}});
  }
  else {*/
    yield call(emitSearch, action.search);
  //}
}
