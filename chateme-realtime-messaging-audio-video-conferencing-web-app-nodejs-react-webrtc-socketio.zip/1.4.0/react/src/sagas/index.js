import { all, takeEvery } from "redux-saga/effects";
import User from "../variables/actions/User";
import {changePictureSaga, listFavoritesSaga, loginSaga, toggleFavoriteSaga, logoutSaga, registerSaga} from './user';
import { ioSaga } from './io';
import { searchSaga } from './search';
import Actions from "../variables/actions/Actions";
import {createRoomSaga, joinRoomSaga, listRoomSaga, moreMessagesSaga, moreImagesSaga, createGroupSaga, moreRoomsSaga} from "./room";
import {sendImageSaga, sendMessageSaga} from "./messaging";
import {uploadSaga} from "./image";
import {
  addPeers,
  setRemoteDescriptionSaga,
  setupListenersSaga,
  gotCandidateSaga,
  closeSaga,
  terminatedSaga,
  switchAudio,
  switchVideo,
  createRoomSaga as rtcCreateRoomSaga,
  enterRoomSaga,
  initConnectionSaga,
  acceptSaga,
  answerSaga,
  switchPeerVideo,
  screenShare,
  stopScreenShare,
} from "./rtc";
import {messageSaga, ringSaga, stopSaga} from "./sounds";
import {selectionChangePictureSaga} from "./selection";
import {createSaga, deleteSaga, updateSaga} from "./admin";

// watcher saga: watches for actions dispatched to the store, starts worker saga
export default function* watcherSaga() {
  yield all([
    takeEvery(Actions.CREATE_ROOM, createRoomSaga),
    takeEvery(Actions.JOIN_ROOM, joinRoomSaga),
    takeEvery(Actions.LIST_ROOMS, listRoomSaga),
    takeEvery(Actions.LIST_FAVORITES, listFavoritesSaga),
    takeEvery(Actions.TOGGLE_FAVORITE, toggleFavoriteSaga),
    takeEvery(Actions.SEND_MESSAGE, sendMessageSaga),
    takeEvery(Actions.SEARCH, searchSaga),
    takeEvery(Actions.UPLOAD_IMAGE, uploadSaga),
    takeEvery(Actions.CHANGE_PICTURE, changePictureSaga),
    takeEvery(Actions.SEND_IMAGE, sendImageSaga),
    takeEvery(Actions.MORE_MESSAGES, moreMessagesSaga),
    takeEvery(Actions.MORE_IMAGES, moreImagesSaga),
    takeEvery(Actions.MORE_ROOMS, moreRoomsSaga),
    takeEvery(Actions.RTC_CLOSE, closeSaga),
    takeEvery(Actions.RTC_TERMINATED, terminatedSaga),
    takeEvery(Actions.RTC_CANDIDATE, gotCandidateSaga),

    takeEvery(Actions.RTC_ROOM_CREATE, rtcCreateRoomSaga),
    takeEvery(Actions.RTC_ROOM_ENTER, enterRoomSaga),
    takeEvery(Actions.RTC_ENTER, initConnectionSaga),
    takeEvery(Actions.RTC_ACCEPT, acceptSaga),
    takeEvery(Actions.RTC_OFFER, answerSaga),
    takeEvery(Actions.RTC_SETUP_LISTENERS, setupListenersSaga),
    takeEvery(Actions.RTC_REMOTE_DESC, setRemoteDescriptionSaga),
    takeEvery(Actions.RTC_SWITCH_AUDIO, switchAudio),
    takeEvery(Actions.RTC_SWITCH_VIDEO, switchVideo),
    takeEvery(Actions.RTC_SWITCH_PEER_VIDEO, switchPeerVideo),
    takeEvery(Actions.RTC_ADD_SELECTED, addPeers),
    takeEvery(Actions.RTC_SCREEN_SHARE, screenShare),
    takeEvery(Actions.RTC_SCREEN_SHARE_STOP, stopScreenShare),

    takeEvery(Actions.SOUNDS_MESSAGE, messageSaga),
    takeEvery(Actions.SOUNDS_RING, ringSaga),
    takeEvery(Actions.SOUNDS_STOP, stopSaga),
    takeEvery(Actions.GROUP_CREATE, createGroupSaga),
    takeEvery(Actions.SELECTION_CHANGE_PICTURE, selectionChangePictureSaga),
    takeEvery(User.USER_LOGIN_SUCCESS, ioSaga),
    takeEvery(User.USER_LOGIN, loginSaga),
    takeEvery(User.USER_REGISTER, registerSaga),
    takeEvery(User.USER_LOGOUT, logoutSaga),

    takeEvery(Actions.ADMIN_USER_CREATE, createSaga),
    takeEvery(Actions.ADMIN_USER_UPDATE, updateSaga),
    takeEvery(Actions.ADMIN_USER_DELETE, deleteSaga),
  ]);
}
