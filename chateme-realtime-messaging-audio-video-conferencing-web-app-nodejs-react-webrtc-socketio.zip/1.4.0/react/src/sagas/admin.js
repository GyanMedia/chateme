import { call, put, select } from "redux-saga/effects";
import jwtDecode from 'jwt-decode';
import User from "../variables/actions/User";

import axios from "axios";
import Actions from "../variables/actions/Actions";
import Config from "../config";

const postCreate = (data, token) => {
    return axios({
        method: "post",
        url: (Config.url || '') + "/api/register",
        data,
        headers: {
            Authorization: 'Bearer ' + token,
        },
    });
};

const postUpdate = (data, token) => {
    return axios({
        method: "post",
        url: (Config.url || '') + "/api/user/edit",
        data,
        headers: {
            Authorization: 'Bearer ' + token,
        },
    });
};

const postDelete = (data, token) => {
    return axios({
        method: "post",
        url: (Config.url || '') + "/api/user/delete",
        data,
        headers: {
            Authorization: 'Bearer ' + token,
        },
    });
};

// worker saga: makes the api call when watcher saga sees the action
export function* createSaga(action) {
    try {
        const token = yield select(state => state.user.token);
        yield call(postCreate, action, token);
        yield put({type: Actions.ADMIN_USER_CREATE_RESULT, username: action.username});
        window.socket.emit('search', { search: action.search })
    }
    catch (error) {

        yield put({type: Actions.ADMIN_USER_CREATE_ERROR, error, username: action.username});
    }
}

export function* updateSaga(action) {
    try {
        const token = yield select(state => state.user.token);
        yield call(postUpdate, action, token);
        yield put({type: Actions.ADMIN_USER_UPDATE_RESULT, username: action.username});
        window.socket.emit('search', { search: action.search })
    }
    catch (error) {
        yield put({type: Actions.ADMIN_USER_UPDATE_ERROR, error, username: action.username});
    }
}


export function* deleteSaga(action) {
    try {
        const token = yield select(state => state.user.token);
        yield call(postDelete, action, token);
        yield put({type: Actions.ADMIN_USER_DELETE_RESULT, email: action.email, username: action.username});
        window.socket.emit('search', { search: action.search })
    }
    catch (error) {
        yield put({type: Actions.ADMIN_USER_DELETE_ERROR, error, username: action.username});
    }
}

