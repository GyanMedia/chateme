import {call} from "redux-saga/effects";
import messageSound from "../assets/message.mp3";
import ringSound from "../assets/ring.mp3";

let ring;

const playMessageSound = () => {
    console.log('message');
    const audio = document.createElement('audio');
    audio.style.display = "none";
    audio.src = messageSound;
    audio.autoplay = true;
    audio.onended = () => audio.remove();
    document.body.appendChild(audio);
};

const stopRinging = () => {
    console.log('stop ringing', ring);
    if (ring) {
        ring.pause();
        ring.remove();
        ring = null;
    }
};

const startRinging = () => {
    console.log('start ringing', ring);
    stopRinging();
    const audio = document.createElement('audio');
    audio.style.display = "none";
    audio.src = ringSound;
    audio.autoplay = true;
    audio.loop = true;
    ring = audio;
};

export function* messageSaga() {
    yield call(playMessageSound);
}

export function* ringSaga() {
    yield call(startRinging);
}

export function* stopSaga() {
    yield call(stopRinging);
}
