import { put, select } from "redux-saga/effects";
import Actions from "../variables/actions/Actions";

export function* selectionChangePictureSaga(action) {
    const {image} = yield select(state => state.images[action.ref]);
    yield put({ type: Actions.SELECTION_SET_PICTURE, picture: image });
}
