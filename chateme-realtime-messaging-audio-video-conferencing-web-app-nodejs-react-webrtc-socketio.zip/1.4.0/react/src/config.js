export default {
    iceServers: [
        { urls: 'turn:51.77.213.241:3478', username: 'clover', credential: 'clover' }, // turn server, required only for clients behind nat
        { urls: 'stun:stun.l.google.com:19302' },
    ],
    demo: true,
    url: 'https://clover.honeyside.it',
    brand: 'Honeyside', // Footer brand
    appName: 'Clover', // App Name
    showCredits: true, // Show credits in login page
};
